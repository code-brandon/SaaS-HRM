package com.xiaozheng.system.b;

/**
 * What --
 * <br>
 * Describe --
 * <br>
 *
 * @Package: com.xiaozheng.system.b
 * @ClassName: A
 * @Author: 小政同学    QQ:xiaozheng666888@qq.com
 * @CreateTime: 2022/3/1 22:01
 */
public interface C extends A,B{
    void msgC();
}
