package com.xiaozheng.system.b;

/**
 * What --
 * <br>
 * Describe --
 * <br>
 *
 * @Package: com.xiaozheng.system.b
 * @ClassName: E
 * @Author: 小政同学    QQ:xiaozheng666888@qq.com
 * @CreateTime: 2022/3/1 22:04
 */
public class F extends E implements C,D{
    @Override
    public void msgC() {

    }

    @Override
    public void msgA() {

    }

    @Override
    public void msgB() {

    }

    @Override
    public void msgD() {

    }
}
