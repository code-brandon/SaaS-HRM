package com.xiaozheng.system.c;

/**
 * What --
 * <br>
 * Describe --
 * <br>
 *
 * @Package: com.xiaozheng.system.c
 * @ClassName: Comparable
 * @Author: 小政同学    QQ:xiaozheng666888@qq.com
 * @CreateTime: 2022/3/1 22:08
 */
public interface Comparable {
    int compareTo(Object obj);
}
